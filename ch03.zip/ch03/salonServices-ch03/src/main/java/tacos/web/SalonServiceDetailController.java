package tacos.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import tacos.RetrieveAvailableSlotService;
import tacos.data.Slot;

import java.util.List;

/**
 * Created by vganesh on 9/17/20.
 */
@RestController
@RequestMapping(path="/", produces = "application/json")
@CrossOrigin(origins = "*")
public class SalonServiceDetailController {
    @Autowired
    private RetrieveAvailableSlotService retrieveAvailableSlotService;
    public SalonServiceDetailController() {
    }
    // http://localhost:5051/retrieveAvailableSlots/1/2020-08-30
    // 2020-11-08 11:19:57.506  INFO 26825 --- [  restartedMain] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/retrieveAvailableSlots],methods=[GET],produces=[application/json]}" onto public java.lang.Iterable<tacos.data.Slot> tacos.web.SalonServiceDetailController.retrieveAvailableSlots(int,java.lang.String)
    @RequestMapping(method = RequestMethod.GET, value="/retrieveAvailableSlots/{salonServiceId}/{formattedDate}",
            headers = "Content-Type=application/json", consumes = "application/json",produces="application/json")
    public Iterable<Slot> retrieveAvailableSlots(@PathVariable(value="salonServiceId")Integer salonServiceId,
                                                 @PathVariable(value="formattedDate")String formattedDate) throws Exception {
        List<Slot> rv = retrieveAvailableSlotService.retrieve(salonServiceId.intValue(), formattedDate);
        if (rv == null ) {
            throw new Exception("Retrieve failed");
        }
        return rv;
    }

}

