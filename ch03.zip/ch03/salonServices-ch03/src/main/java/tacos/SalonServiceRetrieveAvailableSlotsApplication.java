package tacos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SalonServiceRetrieveAvailableSlotsApplication {

  public static void main(String[] args) {
    SpringApplication.run(SalonServiceRetrieveAvailableSlotsApplication.class, args);
  }


  
}
