package tacos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import tacos.data.SelectedService;
import tacos.data.Slot;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.StringTokenizer;

/**
 * Created by vganesh on 11/7/20.
 */
@Service
public class RetrieveAvailableSlotService {
    private static final String RETRIEVE_AVAILABLE_SLOTS = "select s.id, s.locked_at, s.selected_service_id, s.status , s.stylist_name, s.slot_for, sas.available_services_id, ssd.description , ssd.name , ssd.price, ssd.time_in_minutes from slot s, slot_available_services sas, salon_service_detail ssd where s.id  = sas.slot_id and ssd.id = sas.slot_id and s.confirmed_at is null and s.id = ? and CAST(s.slot_for as Date) = ? ";

    @Autowired
    private JdbcTemplate jdbcTemplate;
    public List<Slot> retrieve (int salonServiceId, String formattedDate) {
        System.out.println("retrieve salonServiceId = " + salonServiceId + " formattedDate = " + formattedDate);
        StringTokenizer stringTokenizer=new StringTokenizer(formattedDate,"-");
        String yyyy=null;
        String mm=null;
        String dd=null;
        int counter=0;
        while (stringTokenizer.hasMoreTokens()) {
            if (counter == 0 ) {
                yyyy=stringTokenizer.nextToken();
            } else {
                if (counter == 1 ) {
                    mm=stringTokenizer.nextToken();
                } else {
                    if (counter == 2 ) {
                        dd=stringTokenizer.nextToken();
                    }
                }
            }
            counter++;
        }
//        System.out.println("retrieve yyyy = " + yyyy + " mm = " + mm + " dd = "  + dd);
        List<Slot> queryResults = null;
        if (yyyy != null && mm != null && dd != null ) {
            try {
                String ddMMyyyy=""+dd+"/"+mm+"/"+yyyy;
                java.util.Date utilDate= (java.util.Date) new SimpleDateFormat("dd/MM/yyyy").parse(ddMMyyyy);
                Date sqlDate=new Date(utilDate.getTime());
                queryResults = jdbcTemplate.query(RETRIEVE_AVAILABLE_SLOTS, new Object[]{salonServiceId, sqlDate}, new RowMapper<Slot>() {
                    @Override
                    public Slot mapRow(ResultSet rs, int rowNum) throws SQLException {
                        Slot mySlot = new Slot();
                        mySlot.setId(rs.getBigDecimal("id"));
                        mySlot.setLockedAt(rs.getTimestamp("locked_at"));
                        mySlot.setSlotFor(rs.getTimestamp("slot_for"));
                        mySlot.setStatusInt(rs.getInt("status"));
                        mySlot.setStylistName(rs.getString("stylist_name"));
                        SelectedService selectedService =new SelectedService();
                        selectedService.setId(rs.getBigDecimal("available_services_id"));
                        selectedService.setDescription(rs.getString("description"));
                        selectedService.setName(rs.getString("name"));
                        selectedService.setPrice(rs.getInt("price"));
                        selectedService.setTimeInMinutes(rs.getInt("time_in_minutes"));
                        mySlot.setSelectedService(selectedService);
                        return mySlot;
                    }
                });
            } catch (DataAccessException ex) {
                System.out.println("DataAccessException " + ex.getMessage());
                ex.printStackTrace();
            } catch (ParseException ex) {
                System.out.println("ParseException " + ex.getMessage());
                ex.printStackTrace();
            } finally {
                if (queryResults != null ) {
                    System.out.println("queryResults size = " + queryResults.size());
                }
            }

        }
        return queryResults;
    }

}
