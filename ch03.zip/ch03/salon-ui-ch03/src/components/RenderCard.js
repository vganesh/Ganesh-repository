import React, {  Fragment } from 'react';
import {Card,CardGroup, Button } from 'react-bootstrap';

function RenderCard ({ page }) {
	console.log ('Inside RenderCard page ');
	console.dir (page);
    return (
  	  <Fragment>
<Card>
  <Card.Body>
    <Card.Title >{page.selectedService.name}</Card.Title>
    <Card.Text>{page.stylistName}</Card.Text>
    <Button variant="primary">Book this slot</Button>
  </Card.Body>
</Card>		
  	  </Fragment>
 	 )		        	
	
}
export default RenderCard;
