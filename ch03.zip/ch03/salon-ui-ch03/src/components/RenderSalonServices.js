import React, {  Fragment } from 'react';
import {Row, Col, Button } from 'react-bootstrap';
import RenderCard from './RenderCard';

function RenderSalonServices ({ appState }) {
	console.log ('Inside RenderSalonServices ');
	console.dir (appState);
	if (appState.state !== undefined && appState.state.activity === 'NEXT_PAGE_SUCCESS' && 
        appState.state.page !== undefined) {
		    var rows = [];
			for (var ctr=0; ctr < 3; ctr++) {
				rows.push(<RenderCard page={appState.state.page[ctr]} />)
			}
		    return (
		  <Fragment>
				<Row>
				<Col>
				{rows[0]}
				</Col>
				<Col>
				{rows[1]}
				</Col>
				<Col>
				{rows[2]}
				</Col>
				</Row>
		  </Fragment>
		 	         )		        	
        	
        } else {
		    return (
		  <Fragment>
				<Button variant="primary" onClick={() => appState.nextPage()} >										
						                            Get data
						                        </Button>	
		
		  </Fragment>
		 	         )		        	
        }
}
export default RenderSalonServices;
