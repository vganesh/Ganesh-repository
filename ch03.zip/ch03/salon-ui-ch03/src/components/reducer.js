function reducer (state, action) {
    switch (action.type) {
    case 'NEXT_PAGE_SUCCESS':
		return {...state, page: action.payload, activity: 'NEXT_PAGE_SUCCESS'};
    case 'NEXT_PAGE_FAILED':
		return {...state, error: action.payload, activity: 'NEXT_PAGE_FAILED'};
    case 'PREVIOUS_PAGE_SUCCESS':
		return {...state, page: action.payload, activity: 'PREVIOUS_PAGE_SUCCESS'};
    case 'PREVIOUS_PAGE_FAILED':
		return {...state, error: action.payload, activity: 'PREVIOUS_PAGE_FAILED'};
	default:
	    return state;
	}
}
export default reducer;
