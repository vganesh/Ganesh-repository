import React, {useState} from 'react';
import logo from './logo.svg';
import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import RenderRouter from './components/RenderRouter';

function App() {
    const [counter,setCounter] = useState(0);
    function incrementCounter () {
		setCounter(counter+1);
     }
	 let props={
		 counter: counter, 
		 incrementCounter: incrementCounter
	 }
  return (
    <div className="App">
		  <RenderRouter props={props}/>
    </div>
  );
}

export default App;
