import $ from 'jquery';
const PostPayment = (dispatch, params) => {
    let url = "http://localhost:5051/api/payments/initiate";  
	let headers= {
	          'Content-Type': 'application/json',
	          'Accept-Language': 'en-US',
	          'Accept': '*/*'
		
		}
	    fetch(url, {
	           method: 'POST',
			body: JSON.stringify(params),
			cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached:
	           headers: headers
	       })
		   .then((response) => {
   			if (response.ok) {
	            return response.json(); 				
			} else {
				throw response.statusText;
			}
			   })
		   	.then(function (myJson) {
		               dispatch({
		                   type: 'PAYMENT_SUCCESS',
		                   payload: myJson
		               });
		           })
		.catch(function (err){
			dispatch({
			                    type: 'PAYMENT_FAILED',
			                    payload: {error: 'An  error has happened: ' + err}
			                });
			});		   	
	
}	
export default PostPayment;