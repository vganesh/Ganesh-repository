import $ from 'jquery';
const GetPage = (dispatch, params) => {
    let url = "http://localhost:5051/retrieveAvailableSlots/1/2020-08-30";  
	let headers= {
	          'Content-Type': 'application/json',
	          'Accept-Language': 'en-US',
	          'Accept': '*/*'
		
		}
	    fetch(url, {
	           method: 'GET',
			cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached:
	           headers: headers
	       })
		   .then((response) => {
   			if (response.ok) {
	            return response.json(); 				
			} else {
				throw response.statusText;
			}
			   })
		   	.then(function (myJson) {
		               dispatch({
		                   type: 'NEXT_PAGE_SUCCESS',
		                   payload: myJson
		               });
		           })
		.catch(function (err){
			dispatch({
			                    type: 'NEXT_PAGE_FAILED',
			                    payload: {error: 'An  error has happened: ' + err}
			                });
			});		   	
	
}	
export default GetPage;