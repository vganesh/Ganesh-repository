import React, {  Fragment } from 'react';
import ReactDOM from "react-dom";

import {Card,CardGroup, Button } from 'react-bootstrap';
import { loadStripe } from "@stripe/stripe-js";
import { Elements } from "@stripe/react-stripe-js";
import { BrowserRouter } from "react-router-dom";

import ElementDemos from "./ElementDemos";
import CardForm from "./demos/CardForm";
import FpxBankForm from "./demos/FpxBankForm";
import IbanForm from "./demos/IbanForm";
import IdealBankForm from "./demos/IdealBankForm";
import PaymentRequestForm from "./demos/PaymentRequestForm";
import SplitForm from "./demos/SplitForm";

import "./styles.css";
function CardDetails ({ param }) {
	const stripePromise = loadStripe("pk_test_6pRNASCoBOKtIshFeQd4XMUh");
	
	let payment=undefined; 
	if (param.appState.state.payment.status === 'SUCCESS') {
		payment=param.appState.state.payment; 
	}
	// TODO: Continue further only when payment is not undefined. 
	const demos = [
	  {
	    path: "/card-element",
	    label: "CardElement",
	    component: CardForm
	  },
	  {
	    path: "/split-card-elements",
	    label: "Split Card Elements",
	    component: SplitForm
	  },
	  {
	    path: "/payment-request-button-element",
	    label: "PaymentRequestButtonElement",
	    component: PaymentRequestForm
	  },
	  {
	    path: "/ideal-bank-element",
	    label: "IdealBankElement",
	    component: IdealBankForm
	  },
	  {
	    path: "/iban-element",
	    label: "IbanElement",
	    component: IbanForm
	  },
	  {
	    path: "/fpx-bank-element",
	    label: "FpxBankElement",
	    component: FpxBankForm
	  }
	];
	
    return (
  	  <Fragment>
 	   <Elements stripe={stripePromise}>
       	 <ElementDemos demos={demos} />
      </Elements>
  	  </Fragment>
 	 )		        	
	
}
export default CardDetails;
