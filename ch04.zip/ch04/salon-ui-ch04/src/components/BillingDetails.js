import React, {  Fragment,useState } from 'react';
import {Card,CardGroup, Button, Form, Row, Col } from 'react-bootstrap';

function BillingDetails ({ billing }) {
    const [firstName,setFirstName] = useState('');		
    const [lastName,setLastName] = useState('');		
    const [email,setEmail] = useState('');		
    const [phone,setPhone] = useState('');		
    function textChange(event) {
		if ("firstName" === event.target.id ) {
			setFirstName(event.target.value);			
		} else {
			if ("lastName" === event.target.id ) {
				setLastName(event.target.value);			
			} else {
				if ("email" === event.target.id ) {
					setEmail(event.target.value);			
				} else {
					if ("phone" === event.target.id ) {
						setPhone(event.target.value);			
					}					
				}
				
			}
			
		}
    }
    function onClick() {
		if (firstName.length > 3 && lastName.length > 3 && email.length > 3 && phone.length > 3) {
			let billingDetails={
				firstName: firstName, 
				lastName: lastName, 
				email: email, 
				phoneNumber: phone				
			}			
			billing.processBillingDetails(billingDetails); 
		}
    }
    return (
		<Fragment>
		<Row>
			<Col>
				First Name
			</Col>
			<Col>
				<Form.Control controlid='firstName' id='firstName' type="text" onChange={(e) => textChange(e)} className='fifty-width-inline' value={firstName} />
			</Col>
		</Row>						
		<Row>
			<Col>
				Last Name
			</Col>
			<Col>
				<Form.Control controlid='lastName' id='lastName' type="text" onChange={(e) => textChange(e)} className='fifty-width-inline' value={lastName} />
			</Col>
		</Row>						
		<Row>
			<Col>
				Email address
			</Col>
			<Col>
				<Form.Control controlid='email' id='email' type="text" onChange={(e) => textChange(e)} className='fifty-width-inline' value={email} />
			</Col>
		</Row>						
		<Row>
			<Col>
				Phone Number
			</Col>
			<Col>
				<Form.Control controlid='phone' id='phone' type="text" onChange={(e) => textChange(e)} className='fifty-width-inline' value={phone} />
			</Col>
		</Row>						
		<Row>
			<Col>
				<Button variant="primary" 	onClick={() => onClick()} size="sm" >Make Payment</Button>		
			</Col>
		</Row>						
		</Fragment>
 	 )		        	
	
}
export default BillingDetails;
