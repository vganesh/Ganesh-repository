import React, {  Fragment } from 'react';
import {Card,CardGroup, Button } from 'react-bootstrap';
import BillingDetails from './BillingDetails';
import CardDetails from './CardDetails';
import _ from 'lodash'

function PaymentContainer ({ param }) {
    function processBillingDetails(billingDetails) {
		let result=_.split(param.param.location.pathname,'/',4);
		if (result.length === 4) {
			billingDetails.slotId=result[2];
			billingDetails.selectedServiceId=result[3];			
		}
		param.appState.postPayment(billingDetails);
	}
	// Add more information to billing 
	let billing={
		processBillingDetails: processBillingDetails
	}; 
    return (
  	  <Fragment>
		{param.appState.state.activity === 'PAYMENT_SUCCESS' && (
			<CardDetails param={param} />				
		  )}
  		{param.appState.state.activity !== 'PAYMENT_SUCCESS' && param.param !== undefined && (
  			<BillingDetails billing={billing} />				
  		  )}
		  
		 
  	  </Fragment>
 	 )		        	
	
}
export default PaymentContainer;
