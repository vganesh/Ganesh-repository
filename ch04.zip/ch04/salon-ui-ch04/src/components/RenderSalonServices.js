import React, {  Fragment, useState } from 'react';
import {Row, Col, Button,Form } from 'react-bootstrap';
import RenderCard from './RenderCard';

function RenderSalonServices ({ appState }) {
    const [slotId,setSlotId] = useState(0);		
    const [serviceId,setServiceId] = useState(1);		
	
    function textChange(event) {
		if ("slotId" === event.target.id ) {
			setSlotId(event.target.value);			
		} else {
			if ("serviceId" === event.target.id ) {
				setServiceId(event.target.value);			
			}			
		}
    }
	
    function onClick () {
		if (appState.push ) {
			let routeName='makepayment/'+slotId+'/'+ serviceId +'/serviceName';
			appState.history.push(routeName, { data: 'dummy data goes here' });
		}
    }
	if (appState.state !== undefined && appState.state.activity === 'NEXT_PAGE_SUCCESS' && 
        appState.state.page !== undefined) {
		    var rows = [];
			for (var ctr=0; ctr < 3; ctr++) {
				rows.push(<RenderCard page={appState.state.page[ctr]} />)
			}
			
		    return (
		  <Fragment>
				<Row>
				<Col>
				{rows[0]}
				</Col>
				<Col>
				{rows[1]}
				</Col>
				<Col>
				{rows[2]}
				</Col>
				</Row>
		  </Fragment>
		 	         )		        	
        	
        } else {
		    return (
		  <Fragment>
		<Row>
			<Col>
				Slot Id
			</Col>
			<Col>
				<Form.Control controlid='slotId' id='slotId' type="text" onChange={(e) => textChange(e)} className='fifty-width-inline' value={slotId} />
			</Col>
		</Row>	
		<Row>
			<Col>
				Service Id
			</Col>
			<Col>
				<Form.Control controlid='serviceId' id='serviceId' type="text" onChange={(e) => textChange(e)} className='fifty-width-inline' value={serviceId} />
			</Col>
		</Row>	
		<Row>
			<Col>
				<Button variant="primary" onClick={() => onClick()} >Get data</Button>			
			</Col>
			<Col>
		<Form.Control controlid='hidden' id='hidden' type="hidden" value={appState.counter} />
			</Col>
		</Row>	
				
				
				
		  </Fragment>
		 	         )		        	
        }
}
export default RenderSalonServices;
