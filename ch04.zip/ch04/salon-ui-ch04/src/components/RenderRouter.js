import React, {useState, useReducer, Fragment } from 'react';
import { Route, Switch } from "react-router-dom";

import {Card,CardGroup, Button, Form } from 'react-bootstrap';
// import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import reducer from './reducer';
import { createBrowserHistory } from 'history';
import PaymentContainer  from './PaymentContainer';
import GetPage  from './GetPage';
import PostPayment  from './PostPayment';
import RenderSalonServices from './RenderSalonServices';
import { NavigationBar } from './NavigationBar';

function RenderRouter (props) {
	const history = createBrowserHistory();
    const [page,setPage] = useState(0);
    const [size,setSize] = useState(10);
  	let initialState={page: page, size: size};
    const [state, dispatch] = useReducer(reducer, initialState);
    function nextPage () {
		 setPage(page+1); 
         GetPage(dispatch,page+1)
    }
    function postPayment (params) {
         PostPayment(dispatch,params)
    }
	
  	const location = history.location;
      const [push,setPush] = useState(history.location.pathname === '/' ? true : false);
	
    
      const [appState,setAppState] = useState({
  		  state: state,
  		  nextPage: nextPage,
		  postPayment: postPayment,
  		  history: history,
  		  push: push,
		  counter:  props.props.counter
  	  });
	
  	history.listen((newLocation, action) => {
  	  let newPush=newLocation.location.pathname === '/' ? true : false;
  	  setPush(newPush);
  	  setAppState({...appState, push:newPush, counter: appState.counter+1});
	  props.props.incrementCounter(); // to force rerender
  	});
	
	appState.state=state;
    return (
    <div className="App">
        <NavigationBar />
  		<Switch>
		<Route path={`/makepayment/:slotId/:serviceId/:serviceName`} exact component={(param) => 
			<PaymentContainer param={Object.assign({}, {param: param} ,{appState: appState})} />}	 />
		<Route path="/" component={() => <RenderSalonServices appState={appState} />} />
        </Switch>		
      <header className="App-header">
      </header>
		<Form.Control controlid='hidden' id='hidden' type="hidden" value={props.props.counter} />
		
    </div>
 	 )		        	
	
}
export default RenderRouter;

