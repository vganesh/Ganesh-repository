import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import './bootstrap.min.css';
import './bootstrap-reboot.min.css';
import './bootstrap-grid.min.css';
import './index.css';
import App from './App';
import { createBrowserHistory } from 'history';
import * as serviceWorker from './serviceWorker';
const history = createBrowserHistory();	

const routes = (
    <Router history={history}>
		<App />
    </Router>
);
ReactDOM.render(routes, document.getElementById("root"));

        // <Switch>
        //     <Route path="/home" component={App} />
        // </Switch>

//             <Redirect from="/" to="/home/lectures" />

// ReactDOM.render(
//   <React.StrictMode>
//     <App />
//   </React.StrictMode>,
//   document.getElementById('root')
// );

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
