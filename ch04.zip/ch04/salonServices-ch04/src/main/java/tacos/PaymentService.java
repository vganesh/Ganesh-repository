package tacos;

import tacos.data.PaymentRequest;
import tacos.data.PaymentResponse;

/**
 * Created by vganesh on 12/20/20.
 */
public interface PaymentService {
    PaymentResponse initiatePayment(PaymentRequest paymentRequest);
}
