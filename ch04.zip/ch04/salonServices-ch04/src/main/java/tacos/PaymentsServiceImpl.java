package tacos;

import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import tacos.data.PaymentRequest;
import tacos.data.PaymentResponse;
import tacos.data.SelectedService;
import tacos.data.SlotResponse;
import tacos.entity.*;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;

import static spark.Spark.get;
import static spark.Spark.post;
import static spark.Spark.port;
import static spark.Spark.staticFiles;
import com.google.gson.Gson;

import com.stripe.Stripe;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;
/**
 * Created by vganesh on 11/7/20.
 */
@Service
public class PaymentsServiceImpl implements  PaymentService {
    private static final String RETRIEVE_AVAILABLE_SLOTS = "select s.id, s.locked_at, s.selected_service_id, s.status , s.stylist_name, s.slot_for, sas.available_services_id, ssd.description , ssd.name , ssd.price, ssd.time_in_minutes from slot s, slot_available_services sas, salon_service_detail ssd where s.id  = sas.slot_id and ssd.id = sas.slot_id and s.confirmed_at is null and s.id = ? and CAST(s.slot_for as Date) = ? ";
    @Autowired
    private SlotRepository slotRepository;
    @Autowired
    private SalonServiceDetailRepository salonServiceDetailRepository;
    @Autowired
    private PaymentRepository paymentRepository;
    @Autowired
    private JdbcTemplate jdbcTemplate;
    public List<SlotResponse> retrieve (int salonServiceId, String formattedDate) {
        StringTokenizer stringTokenizer=new StringTokenizer(formattedDate,"-");
        String yyyy=null;
        String mm=null;
        String dd=null;
        int counter=0;
        while (stringTokenizer.hasMoreTokens()) {
            if (counter == 0 ) {
                yyyy=stringTokenizer.nextToken();
            } else {
                if (counter == 1 ) {
                    mm=stringTokenizer.nextToken();
                } else {
                    if (counter == 2 ) {
                        dd=stringTokenizer.nextToken();
                    }
                }
            }
            counter++;
        }
        List<SlotResponse> queryResults = null;
        if (yyyy != null && mm != null && dd != null ) {
            try {
                String ddMMyyyy=""+dd+"/"+mm+"/"+yyyy;
                java.util.Date utilDate= (java.util.Date) new SimpleDateFormat("dd/MM/yyyy").parse(ddMMyyyy);
                Date sqlDate=new Date(utilDate.getTime());
                queryResults = jdbcTemplate.query(RETRIEVE_AVAILABLE_SLOTS, new Object[]{salonServiceId, sqlDate}, new RowMapper<SlotResponse>() {
                    @Override
                    public SlotResponse mapRow(ResultSet rs, int rowNum) throws SQLException {
                        SlotResponse mySlot = new SlotResponse();
//                        mySlot.setId(rs.getBigDecimal("id"));
                        mySlot.setLockedAt(rs.getTimestamp("locked_at"));
                        mySlot.setSlotFor(rs.getTimestamp("slot_for"));
                        mySlot.setStatusInt(rs.getInt("status"));
                        mySlot.setStylistName(rs.getString("stylist_name"));
                        SelectedService selectedService =new SelectedService();
//                        selectedService.setId(rs.getBigDecimal("available_services_id"));
                        selectedService.setDescription(rs.getString("description"));
                        selectedService.setName(rs.getString("name"));
                        selectedService.setPrice(rs.getInt("price"));
                        selectedService.setTimeInMinutes(rs.getInt("time_in_minutes"));
                        mySlot.setSelectedService(selectedService);
                        return mySlot;
                    }
                });
            } catch (DataAccessException ex) {
                System.out.println("DataAccessException " + ex.getMessage());
                ex.printStackTrace();
            } catch (ParseException ex) {
                System.out.println("ParseException " + ex.getMessage());
                ex.printStackTrace();
            } finally {
                if (queryResults != null ) {
                    System.out.println("queryResults size = " + queryResults.size());
                }
            }

        }
        return queryResults;
    }

    @Override
    public PaymentResponse initiatePayment(PaymentRequest paymentRequest) {
        System.out.println("initiatePayment");
        PaymentResponse paymentResponse = new PaymentResponse();
        paymentResponse.setStatus("ERROR");
        if (paymentRequest != null ) {
            Optional<Slot> slotOpt = slotRepository.findById(paymentRequest.getSlotId());
            Optional<SalonServiceDetail> salonServiceDetailOpt = salonServiceDetailRepository.findById(paymentRequest.getSelectedServiceId());
            if (slotOpt.isPresent() && salonServiceDetailOpt.isPresent()) {
                if (slotOpt.get().getStatus() == 0) {
                    Stripe.apiKey = "sk_test_51I0V0vJ7vTU66BZvnRjajNya5snk8aiAQDf3esffYwsNDX4mLXHaiz9lnraenz4Yl94Sz4nINX1RX42Wj3IY1Jza00TMFsMr6r";
                    List<Object> paymentMethodTypes =
                            new ArrayList<>();
                    paymentMethodTypes.add("card");
                    Map<String, Object> params = new HashMap<>();
                    params.put("amount", salonServiceDetailOpt.get().getPrice());
                    params.put("currency", "usd");
                    params.put("payment_method_types", paymentMethodTypes);
                    try {
                        PaymentIntent paymentIntent =
                                PaymentIntent.create(params);
                        System.out.println("paymentIntent " + paymentIntent);
                        Payment payment=new Payment();
                        Integer amt = salonServiceDetailOpt.get().getPrice();;
                        payment.setClientSecret(paymentIntent.getClientSecret());
                        Timestamp currentTimeStamp = new Timestamp(System.currentTimeMillis());
                        payment.setCreated(currentTimeStamp);
                        payment.setAmount(amt.longValue());
                        payment.setEmail(paymentRequest.getEmail());
                        payment.setFirstName(paymentRequest.getFirstName());
                        payment.setLastName(paymentRequest.getLastName());
                        paymentRequest.setSelectedServiceId(salonServiceDetailOpt.get().getId());
                        paymentRequest.setSlotId(slotOpt.get().getId());
                        payment.setIntentId(paymentIntent.getId());

                        Payment savedPayment = paymentRepository.save(payment);
                        paymentResponse.setStatus("SUCCESS");
                        paymentResponse.setFirstName(savedPayment.getFirstName());
                        paymentResponse.setAmount(savedPayment.getAmount());
                        paymentResponse.setLastName(savedPayment.getLastName());
                        paymentResponse.setEmail(savedPayment.getEmail());
                        paymentResponse.setCreated(currentTimeStamp);
                        paymentResponse.setClientSecret(paymentIntent.getClientSecret());
                        paymentResponse.setIntendId(paymentIntent.getId());
                        SelectedService selectedService= new SelectedService();
                        selectedService.setTimeInMinutes(salonServiceDetailOpt.get().getTimeInMinutes());
                        selectedService.setPrice(salonServiceDetailOpt.get().getPrice());
                        selectedService.setDescription(salonServiceDetailOpt.get().getDescription());
                        selectedService.setId(salonServiceDetailOpt.get().getId());
                        selectedService.setName(salonServiceDetailOpt.get().getName());
                        paymentResponse.setSelectedService(selectedService);
                        slotOpt.get().setStatus(1L);
                        slotOpt.get().setSelectedServiceId(salonServiceDetailOpt.get().getId());
                        Slot savedSlot = slotRepository.save(slotOpt.get());

                    } catch (StripeException e) {
                        e.printStackTrace();
                    }
                }
            } else {
            }
        }
        return paymentResponse;
    }
}
