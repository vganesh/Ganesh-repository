package tacos.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;
import tacos.PaymentService;
import tacos.data.PaymentRequest;
import tacos.data.PaymentResponse;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URI;

/**
 * Created by vganesh on 9/17/20.
 */
@RestController
@RequestMapping(path="/", produces = "application/json")
@CrossOrigin(origins = "*")
public class PaymentServiceController {
    @Autowired
    private PaymentService paymentService;

    @RequestMapping(method = RequestMethod.POST, value="/api/payments/initiate",
            headers = "Content-Type=application/json", consumes = "application/json",produces="application/json")
    ResponseEntity<PaymentResponse> initiatePayment(HttpServletRequest request,HttpServletResponse response,
                                    @RequestBody PaymentRequest paymentRequest,UriComponentsBuilder ucb) throws Exception {
        PaymentResponse paymentResponse=paymentService.initiatePayment(paymentRequest);
        HttpHeaders headers = new HttpHeaders();
        URI locationUri = ucb.path("/lectures/")
                .path(String.valueOf(paymentResponse.getId()))
                .build()
                .toUri();
        headers.setLocation(locationUri);
        ResponseEntity<PaymentResponse> responseEntity = new ResponseEntity<PaymentResponse>(paymentResponse, headers, HttpStatus.CREATED);
        return responseEntity;
    }
    @RequestMapping(method = RequestMethod.POST, value="/api/payments/initiate/success",
            headers = "Content-Type=application/json", consumes = "application/json")
    void initialeSuccess(@RequestBody String successBody) {
        System.out.println("Success " + successBody);
    }
    @RequestMapping(method = RequestMethod.POST, value="/api/payments/initiate/cancel",
            headers = "Content-Type=application/json", consumes = "application/json")
    void initialeCancel(@RequestBody String cancelBody) {
        System.out.println("Cancel " + cancelBody);
    }

}

