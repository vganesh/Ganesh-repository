package tacos.data;

import lombok.Data;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * Created by vganesh on 11/8/20.
 */
@Data
public class PaymentTmp {
    private BigDecimal id;	
    // private String paymentId;
	private SalonServiceDetailResponse salonServiceDetailResponse;
	private Long amount; 
	private int status; 
    private Timestamp created;
    private Timestamp updatedTimestamp;
	private String intendId; 
	private String clientSecret; 
	private String firstName; 
	private String lastName; 
	private String email; 
	private String phoneNumber; 
    private BigDecimal selectedServiceId;	
    private BigDecimal slotId;	
}
