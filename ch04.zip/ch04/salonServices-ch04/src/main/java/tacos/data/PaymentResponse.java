package tacos.data;

import lombok.Data;

import java.sql.Timestamp;

/**
 * Created by vganesh on 12/20/20.
 */
@Data
public class PaymentResponse {
    private long id;
    private long amount;
    private long asCents;
    private String clientSecret;
    private Timestamp created;
    private String email;
    private String firstName;
    private String lastName;
    private String intendId;
    private String name;
    private String phoneNumber;
    private SelectedService selectedService;
    private SlotResponse slot;
    private String status;
    private String updated;
}
