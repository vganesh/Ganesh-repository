package tacos.data;

import lombok.Data;

import java.math.BigDecimal;

/**
 * Created by vganesh on 12/20/20.
 */
@Data
public class PaymentRequest {
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private Long selectedServiceId;
    private Long slotId;
}
