package tacos.data;

import lombok.Data;

import java.math.BigDecimal;

/**
 * Created by vganesh on 11/8/20.
 */
@Data
public class SelectedService {
    private long id;
    private String description;
    private String name;
    private int price;
    private int timeInMinutes;
}
