package tacos.data;

import lombok.Data;

import java.math.BigDecimal;

/**
 * Created by vganesh on 11/8/20.
 */
@Data
public class SalonServiceDetailResponse {
    private BigDecimal id;
    private String description;
    private String name;
    private Integer price;
    private Integer timeInMinutes;
	
    // private String paymentId;

}
