package tacos.data;

import lombok.Data;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by vganesh on 11/7/20.
 */
@Data
public class SlotResponse {
    private long id;
    private Date confirmedAt;
    private Timestamp lockedAt;
    private Timestamp slotFor;
    private String status;
    private String stylistName;
    private SelectedService selectedService;
    public void setStatusInt(int status) {
        if (status == 0) {
            this.status="AVAILABLE";
        } else {
            this.status="NOT_AVAILABLE";
        }
    }
}
