package tacos.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.ToString;
import tacos.data.SalonServiceDetailResponse;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * Created by vganesh on 12/20/20.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
//@AllArgsConstructor
//@NoArgsConstructor
@ToString
@Entity
//@Table(name = "slot")
public class Payment {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    private Long amount;
    private String clientSecret;
    private Timestamp created;
    private String email;
    private String firstName;
    private String intentId;
    private String lastName;
    private String phoneNumber;
    private int status;
    private Timestamp updated;
    private BigDecimal selectedServiceId;
    private BigDecimal slotId;
}
