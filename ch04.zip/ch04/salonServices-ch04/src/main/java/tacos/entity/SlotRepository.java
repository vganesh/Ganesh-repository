package tacos.entity;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by vganesh on 12/20/20.
 */
@Repository
public interface SlotRepository extends PagingAndSortingRepository<Slot, Long>, JpaSpecificationExecutor<Slot> {

}
