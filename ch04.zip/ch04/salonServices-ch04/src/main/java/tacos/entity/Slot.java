package tacos.entity;

import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.ToString;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.sql.Date;
import java.sql.Timestamp;
/**
 * Created by vganesh on 12/20/20.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
//@AllArgsConstructor
//@NoArgsConstructor
@ToString
@Entity
//@Table(name = "slot")
public class Slot {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    private Timestamp confirmedAt;
    private Timestamp lockedAt;
    private Timestamp slotFor;
    private Long status;
    private String stylistName;
    private Long selectedServiceId;

}
