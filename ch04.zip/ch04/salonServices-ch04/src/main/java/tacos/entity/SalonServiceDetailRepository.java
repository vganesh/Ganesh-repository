package tacos.entity;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by vganesh on 12/20/20.
 */
@Repository
public interface SalonServiceDetailRepository extends PagingAndSortingRepository<SalonServiceDetail, Long>, JpaSpecificationExecutor<SalonServiceDetail> {

}
