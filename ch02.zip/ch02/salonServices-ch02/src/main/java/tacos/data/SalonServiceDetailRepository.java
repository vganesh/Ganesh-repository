package tacos.data;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import tacos.SalonServiceDetail;

/**
 * Created by vganesh on 9/17/20.
 */
public interface SalonServiceDetailRepository extends PagingAndSortingRepository<SalonServiceDetail, Long> {
}

