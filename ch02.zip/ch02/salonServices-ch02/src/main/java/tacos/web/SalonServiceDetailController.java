package tacos.web;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;
import tacos.SalonServiceDetail;
import tacos.data.SalonServiceDetailRepository;

import java.util.List;

/**
 * Created by vganesh on 9/17/20.
 */
@RestController
@RequestMapping(path="/", produces = "application/json")
@CrossOrigin(origins = "*")
public class SalonServiceDetailController {
    private SalonServiceDetailRepository serviceDetailRepository;

    public SalonServiceDetailController(SalonServiceDetailRepository serviceDetailRepository) {
        this.serviceDetailRepository=serviceDetailRepository;
    }

    @GetMapping("/services")
    public Iterable<SalonServiceDetail> services(@RequestParam(value="startPage", defaultValue="0", required = false) Integer startPage,
                                             @RequestParam(value="startPage", defaultValue="10", required = false) Integer size) {
        PageRequest page = PageRequest.of(
                startPage, size, Sort.by("name").descending());
        return serviceDetailRepository.findAll(page).getContent();
    }

}
