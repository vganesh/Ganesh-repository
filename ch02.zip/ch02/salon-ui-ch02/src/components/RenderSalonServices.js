import React, {  Fragment } from 'react';
import { Button } from 'react-bootstrap';

function RenderSalonServices ({ appState }) {
	console.log ('Inside RenderSalonServices ');
	console.dir (appState);
	if (appState.state != undefined && appState.state.activity == 'NEXT_PAGE_SUCCESS' && 
        appState.state.page != undefined) {
		    return (
		  <Fragment>
				<ul> 
                {appState.state.page.map(({ description }) => (
					<li>{description}</li>
                ))}
				</ul>
		  </Fragment>
		 	         )		        	
        	
        } else {
		    return (
		  <Fragment>
				<Button variant="primary" onClick={() => appState.nextPage()} >										
						                            Get data
						                        </Button>	
		
		  </Fragment>
		 	         )		        	
        }
}
export default RenderSalonServices;
