import $ from 'jquery';
const GetPage = (dispatch, params) => {
    let url = "http://localhost:5050/services";  
	let headers= {
	          'Content-Type': 'application/json',
	          'Accept-Language': 'en-US',
	          'Accept': '*/*'
		
		}
	    fetch(url, {
	           method: 'GET',
			cache: 'no-cache', 
	           headers: headers
	       })
		   .then((response) => {
   			if (response.ok) {
	            return response.json(); 				
			} else {
				throw response.statusText;
			}
			   })
		   	.then(function (myJson) {
		               dispatch({
		                   type: 'NEXT_PAGE_SUCCESS',
		                   payload: myJson
		               });
		           })
		.catch(function (err){
			dispatch({
			                    type: 'NEXT_PAGE_FAILED',
			                    payload: {error: 'An  error has happened: ' + err}
			                });
			});		   	
	
}	
export default GetPage;