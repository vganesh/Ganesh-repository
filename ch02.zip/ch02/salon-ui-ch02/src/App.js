import React, {useState, useReducer } from 'react';
import logo from './logo.svg';
import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { NavigationBar } from './components/NavigationBar';
import RenderSalonServices from './components/RenderSalonServices';
import reducer from './components/reducer';
import GetPage  from './components/GetPage';

function App() {
    const [page,setPage] = useState(0);
    const [size,setSize] = useState(10);
	let initialState={page: page, size: size};
	
    const [state, dispatch] = useReducer(reducer, initialState);
	
    function nextPage () {
		 setPage(page+1); 
         GetPage(dispatch,page+1)
      }
	  let appState={
		  state: state,
		  nextPage: nextPage
	  }
  return (
    <div className="App">
	  <Router>
        <NavigationBar />
	  </Router>
      <header className="App-header">
		  <RenderSalonServices appState={appState} />
      </header>
    </div>
  );
}

export default App;
